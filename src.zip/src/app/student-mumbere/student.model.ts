export interface Student{
  id: string;
  name: string;
  image: string;
  description: string;
  skills: string;
  gallery: string[];
}
