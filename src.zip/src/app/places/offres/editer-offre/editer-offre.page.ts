import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editer-offre',
  templateUrl: './editer-offre.page.html',
  styleUrls: ['./editer-offre.page.scss'],
})
export class EditerOffrePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
