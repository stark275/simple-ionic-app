import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offre-reservation',
  templateUrl: './offre-reservation.page.html',
  styleUrls: ['./offre-reservation.page.scss'],
})
export class OffreReservationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
