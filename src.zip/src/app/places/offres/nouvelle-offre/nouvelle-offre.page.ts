import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nouvelle-offre',
  templateUrl: './nouvelle-offre.page.html',
  styleUrls: ['./nouvelle-offre.page.scss'],
})
export class NouvelleOffrePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
