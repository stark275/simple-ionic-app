export class Place{


    constructor(
public id: string,
public titre: string,
public description: string,
public imageUrl: string,
public prix: number
    ){}
}
